package com.cg.otms.qs.service;

public class QuestionService
{
	
}
