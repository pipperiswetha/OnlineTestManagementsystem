package com.cg.otms.qs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuestionServiceApplicationTests 
{	
	@Test
	public void testgetQuestion_Positive() throws Exception
	{
		 
	}
}


	


