package com.cg.otms.qs.service;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class TestQuestionService 
{
	
 @Test
	  public void testgetQuestion_Positive() throws Exception
	   {
	  	  
	    }
	    
	    @Test
	    public void testgetQuestion_Negative() throws Exception
	    {
	  	 
	    }
	    
	    
}
